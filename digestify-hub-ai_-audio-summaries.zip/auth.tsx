
import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import type { User } from './types';

// WARNING: This is a mock authentication for demo purposes.
// Do not use this in a production environment. It uses localStorage and is not secure.

interface AuthContextType {
    user: User | null;
    signIn: (username: string, pass: string) => boolean;
    signUp: (username: string, pass: string) => boolean;
    signOut: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [user, setUser] = useState<User | null>(() => {
        try {
            const storedUser = localStorage.getItem('currentUser');
            return storedUser ? JSON.parse(storedUser) : null;
        } catch {
            return null;
        }
    });

    useEffect(() => {
        if (user) {
            localStorage.setItem('currentUser', JSON.stringify(user));
        } else {
            localStorage.removeItem('currentUser');
        }
    }, [user]);

    const getUsers = () => {
        try {
            const users = localStorage.getItem('users');
            return users ? JSON.parse(users) : {};
        } catch {
            return {};
        }
    };

    const setUsers = (users: any) => {
        localStorage.setItem('users', JSON.stringify(users));
    };

    const signIn = (username: string, pass: string) => {
        const users = getUsers();
        if (users[username] && users[username] === pass) {
            const loggedInUser = { username };
            setUser(loggedInUser);
            return true;
        }
        return false;
    };

    const signUp = (username: string, pass: string) => {
        const users = getUsers();
        if (users[username]) {
            return false; // User already exists
        }
        users[username] = pass;
        setUsers(users);
        const newUser = { username };
        setUser(newUser);
        return true;
    };

    const signOut = () => {
        setUser(null);
    };

    const value = { user, signIn, signUp, signOut };

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};

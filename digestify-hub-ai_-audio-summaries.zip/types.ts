
export interface User {
  username: string;
}

export interface Voice {
  id: string;
  name: string;
}

export interface Language {
  id: string;
  name: string;
}
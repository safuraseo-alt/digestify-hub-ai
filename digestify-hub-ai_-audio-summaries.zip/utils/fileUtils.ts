
export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // result is a data URL (e.g., data:audio/mpeg;base64,...)
      // We only want the base64 part, so we split on the comma and take the second part.
      resolve(result.split(',')[1]);
    };
    reader.onerror = (error) => reject(error);
  });
}

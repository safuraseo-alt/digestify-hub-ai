

import React from 'react';

const AboutUsPage: React.FC = () => {
  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <main className="bg-white dark:bg-zinc-900 rounded-2xl shadow-lg shadow-custom-primary/10 p-6 sm:p-8 space-y-6 text-custom-subtitle dark:text-gray-300 leading-relaxed mt-8">
          <p>
            Welcome to <strong>Digestify Hub AI</strong>, your personal audio digest powered by Google's state-of-the-art Gemini API. In a world overflowing with information, staying updated can be a challenge, especially with a busy lifestyle. We created this application to solve that problem.
          </p>
          <p>
            Our mission is to make information accessible and digestible. Whether you're commuting, working out, or simply taking a break, you can catch up on the articles and documents that matter to you, in your chosen language and voice.
          </p>
          
          <div className="border-t border-gray-200 dark:border-gray-700 my-6"></div>

          <h2 className="text-2xl font-bold text-custom-text dark:text-white mb-4">Core Features</h2>
          <ul className="list-disc list-inside space-y-2">
            <li><strong>Personalized Summaries:</strong> Go beyond generic summaries. Provide your own instructions to tailor the summary's tone, focus, and style to your needs.</li>
            <li><strong>Text-to-Speech:</strong> Convert any summary into high-quality, natural-sounding audio with a selection of voices.</li>
            <li><strong>Multi-Lingual Support:</strong> Generate summaries and audio in various languages to break down language barriers.</li>
            <li><strong>Audio Transcription:</strong> Upload an audio file or record your voice directly to get an accurate text transcription, perfect for converting lectures, meetings, or voice notes into text.</li>
            <li><strong>Video to Text Summarization:</strong> (New!) Upload a video file to get a concise summary of its content.</li>
            <li><strong>Flexible Input:</strong> Paste text directly, upload a PDF, or provide a URL to get the content you need summarized.</li>
          </ul>

          <div className="border-t border-gray-200 dark:border-gray-700 my-6"></div>
          
          <p>
            This entire application is built to showcase the power and versatility of the Gemini API. From complex reasoning for summarization to generating human-like speech and transcribing audio, Gemini makes it possible to create intelligent, helpful, and multimodal applications. We hope Digestify Hub AI enhances your productivity and learning journey.
          </p>
        </main>
      </div>
    </div>
  );
};

export default AboutUsPage;
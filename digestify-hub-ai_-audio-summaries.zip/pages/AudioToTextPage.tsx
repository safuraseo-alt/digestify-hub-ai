
import React, { useState, useRef, useEffect } from 'react';
import { transcribeAudio } from '../services/geminiService';
import { ArrowUpTrayIcon, LoaderIcon, WaveformIcon, DocumentTextIcon, ClipboardDocumentListIcon, DownloadIcon, MicrophoneIcon, StopIcon } from '../components/icons';

type InputType = 'upload' | 'record';

const AudioToTextPage: React.FC = () => {
    const [audioFile, setAudioFile] = useState<File | null>(null);
    const [transcription, setTranscription] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    
    const [inputType, setInputType] = useState<InputType>('upload');
    const [isRecording, setIsRecording] = useState<boolean>(false);
    const [recordingTime, setRecordingTime] = useState<number>(0);
    const [audioUrl, setAudioUrl] = useState<string | null>(null);

    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);
    const timerIntervalRef = useRef<number | null>(null);

    useEffect(() => {
        // Cleanup URL object when component unmounts or audio file changes
        return () => {
            if (audioUrl) {
                URL.revokeObjectURL(audioUrl);
            }
        };
    }, [audioUrl]);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setAudioFile(file);
            setAudioUrl(URL.createObjectURL(file));
            setTranscription('');
            setError(null);
        }
    };

    const handleTranscribe = async () => {
        if (!audioFile) {
            setError('Please select or record an audio file first.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setTranscription('');
        try {
            const result = await transcribeAudio(audioFile);
            setTranscription(result);
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
            setError(errorMessage);
        } finally {
            setIsLoading(false);
        }
    };

    const handleCopyToClipboard = () => {
        if (transcription) {
            navigator.clipboard.writeText(transcription);
        }
    };

    const handleDownload = () => {
        if (!transcription) return;

        const blob = new Blob([transcription], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'transcription.txt';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const startTimer = () => {
        const startTime = Date.now();
        timerIntervalRef.current = window.setInterval(() => {
            setRecordingTime(Math.floor((Date.now() - startTime) / 1000));
        }, 1000);
    };

    const stopTimer = () => {
        if (timerIntervalRef.current) {
            clearInterval(timerIntervalRef.current);
            timerIntervalRef.current = null;
        }
        setRecordingTime(0);
    };

    const handleStartRecording = async () => {
        setAudioFile(null);
        setTranscription('');
        setError(null);
        if (audioUrl) URL.revokeObjectURL(audioUrl);
        setAudioUrl(null);

        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorderRef.current = new MediaRecorder(stream);
            audioChunksRef.current = [];

            mediaRecorderRef.current.ondataavailable = (event) => {
                audioChunksRef.current.push(event.data);
            };

            mediaRecorderRef.current.onstop = () => {
                const mimeType = mediaRecorderRef.current?.mimeType || 'audio/webm';
                const audioBlob = new Blob(audioChunksRef.current, { type: mimeType });
                const extension = mimeType.split('/')[1].split(';')[0];
                const recordedFile = new File([audioBlob], `recording-${Date.now()}.${extension}`, { type: mimeType });
                
                setAudioFile(recordedFile);
                setAudioUrl(URL.createObjectURL(recordedFile));
                stream.getTracks().forEach(track => track.stop());
            };

            mediaRecorderRef.current.start();
            setIsRecording(true);
            startTimer();
        } catch (err) {
            console.error("Error starting recording:", err);
            setError("Could not access microphone. Please check permissions and try again.");
        }
    };

    const handleStopRecording = () => {
        if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
            mediaRecorderRef.current.stop();
        }
        setIsRecording(false);
        stopTimer();
    };

    useEffect(() => {
        return () => {
            stopTimer();
            if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
                mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
                mediaRecorderRef.current.stop();
            }
        };
    }, []);

    const formatTime = (seconds: number) => {
        const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
        const secs = (seconds % 60).toString().padStart(2, '0');
        return `${mins}:${secs}`;
    };

    const TabButton: React.FC<{ type: InputType; label: string; icon: React.ReactNode }> = ({ type, label, icon }) => (
        <button
            onClick={() => { setInputType(type); setError(null); }}
            className={`flex items-center justify-center w-full px-4 py-3 font-semibold text-sm rounded-t-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-custom-primary focus:ring-offset-2 dark:focus:ring-offset-zinc-900 ${
                inputType === type
                ? 'bg-white dark:bg-zinc-800 text-custom-primary border-b-2 border-custom-primary'
                : 'bg-transparent text-custom-subtitle hover:bg-gray-100 dark:hover:bg-zinc-800'
            }`}
        >
            {icon}
            {label}
        </button>
    );

    return (
        <div className="p-4 sm:p-6 lg:p-8">
            <div className="max-w-4xl mx-auto">
                <main className="space-y-8 mt-8">
                    <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-lg shadow-custom-primary/10 p-6 sm:p-8 space-y-6">
                        <div>
                            <label className="flex items-center text-lg font-semibold mb-2 text-custom-text dark:text-gray-200">
                                <WaveformIcon className="w-6 h-6 mr-2 text-custom-primary" />
                                1. Provide Your Audio
                            </label>
                            <div className="border-b border-gray-200 dark:border-gray-700">
                                <nav className="-mb-px flex space-x-2" aria-label="Tabs">
                                    <TabButton type="upload" label="Upload File" icon={<ArrowUpTrayIcon className="w-5 h-5 mr-2" />} />
                                    <TabButton type="record" label="Record Audio" icon={<MicrophoneIcon className="w-5 h-5 mr-2" />} />
                                </nav>
                            </div>
                            <div className="mt-4">
                                {inputType === 'upload' && (
                                    <div className="flex flex-col items-center justify-center w-full min-h-[12rem] p-4 bg-custom-bg dark:bg-zinc-800 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg">
                                        <input
                                            type="file"
                                            id="audio-upload"
                                            accept="audio/*"
                                            onChange={handleFileChange}
                                            className="hidden"
                                            ref={fileInputRef}
                                        />
                                        <button
                                            onClick={() => fileInputRef.current?.click()}
                                            disabled={isLoading}
                                            className="inline-flex items-center px-4 py-2 bg-custom-primary text-white font-semibold rounded-lg hover:bg-custom-primary-hover disabled:bg-gray-400"
                                        >
                                            <ArrowUpTrayIcon className="w-5 h-5 mr-2" />
                                            Select Audio File
                                        </button>
                                        {audioFile && inputType === 'upload' && (
                                            <div className="mt-4 text-center">
                                                <p className="text-sm text-custom-subtitle dark:text-gray-400">
                                                    Selected: <span className="font-medium">{audioFile.name}</span>
                                                </p>
                                                {audioUrl && <audio src={audioUrl} controls className="mt-2 w-full max-w-sm"/>}
                                            </div>
                                        )}
                                    </div>
                                )}
                                {inputType === 'record' && (
                                    <div className="flex flex-col items-center justify-center w-full min-h-[12rem] p-4 bg-custom-bg dark:bg-zinc-800 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg">
                                        {!isRecording && !audioFile && (
                                            <>
                                                <button onClick={handleStartRecording} className="inline-flex items-center px-4 py-2 bg-custom-primary text-white font-semibold rounded-lg hover:bg-custom-primary-hover">
                                                    <MicrophoneIcon className="w-5 h-5 mr-2" />
                                                    Start Recording
                                                </button>
                                                <p className="mt-2 text-sm text-custom-subtitle dark:text-gray-400">Click to start recording</p>
                                            </>
                                        )}
                                        {isRecording && (
                                            <div className="flex flex-col items-center justify-center gap-4">
                                                <div className="flex items-center space-x-3 text-red-500">
                                                    <span className="relative flex h-3 w-3">
                                                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                                                        <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                                                    </span>
                                                    <p className="font-mono text-lg font-semibold">{formatTime(recordingTime)}</p>
                                                </div>
                                                <button onClick={handleStopRecording} className="inline-flex items-center px-4 py-2 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700">
                                                    <StopIcon className="w-5 h-5 mr-2" />
                                                    Stop Recording
                                                </button>
                                            </div>
                                        )}
                                        {!isRecording && audioFile && (
                                             <div className="text-center">
                                                <p className="text-sm text-custom-subtitle dark:text-gray-400">
                                                    Recording complete.
                                                </p>
                                                {audioUrl && <audio src={audioUrl} controls className="mt-2 w-full max-w-sm"/>}
                                                <button onClick={handleStartRecording} className="mt-4 text-sm font-semibold text-custom-primary hover:underline">
                                                    Record Again
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>

                        <button
                            onClick={handleTranscribe}
                            disabled={!audioFile || isLoading}
                            className="w-full flex-grow inline-flex items-center justify-center px-8 py-3 bg-custom-secondary text-custom-text font-bold rounded-lg hover:opacity-90 disabled:bg-gray-300 dark:disabled:bg-zinc-700 disabled:text-gray-500 dark:disabled:text-gray-400 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 disabled:scale-100 shadow-lg shadow-custom-secondary/30"
                        >
                            {isLoading ? (
                                <>
                                    <LoaderIcon className="w-6 h-6 mr-3 animate-spin" />
                                    Transcribing...
                                </>
                            ) : (
                                <>
                                    <DocumentTextIcon className="w-6 h-6 mr-3" />
                                    Transcribe Audio
                                </>
                            )}
                        </button>
                        {error && <p className="text-red-600 dark:text-red-400 mt-2 text-center">{error}</p>}
                    </div>

                    {(transcription || isLoading) && (
                        <div className={`transition-opacity duration-500 ${isLoading && !transcription ? 'opacity-50' : 'opacity-100'}`}>
                             <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-lg shadow-custom-primary/10 p-6 sm:p-8 space-y-4">
                                <div className="flex justify-between items-center">
                                    <h2 className="text-2xl font-bold text-custom-text dark:text-white">Transcription Result</h2>
                                    <div className="flex items-center space-x-4">
                                        <button 
                                            onClick={handleCopyToClipboard}
                                            disabled={!transcription}
                                            className="flex items-center text-sm font-semibold text-custom-primary hover:underline disabled:opacity-50"
                                            aria-label="Copy to clipboard"
                                        >
                                            <ClipboardDocumentListIcon className="w-5 h-5 mr-2"/>
                                            Copy
                                        </button>
                                        <button
                                            onClick={handleDownload}
                                            disabled={!transcription}
                                            className="flex items-center text-sm font-semibold text-custom-primary hover:underline disabled:opacity-50"
                                            aria-label="Download transcription"
                                        >
                                            <DownloadIcon className="w-5 h-5 mr-2" />
                                            Download
                                        </button>
                                    </div>
                                </div>
                                <div className="bg-custom-bg/70 dark:bg-dark-bg/70 p-6 rounded-lg min-h-[150px]">
                                    {transcription ? (
                                        <p className="text-custom-text dark:text-gray-300 leading-relaxed whitespace-pre-wrap">{transcription}</p>
                                    ) : (
                                        <div className="space-y-3 animate-pulse">
                                            <div className="h-4 bg-gray-300 dark:bg-zinc-700 rounded w-3/4"></div>
                                            <div className="h-4 bg-gray-300 dark:bg-zinc-700 rounded w-full"></div>
                                            <div className="h-4 bg-gray-300 dark:bg-zinc-700 rounded w-5/6"></div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                </main>
            </div>
        </div>
    );
};

export default AudioToTextPage;

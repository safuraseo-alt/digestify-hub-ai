import React, { useState, useRef, useCallback, useEffect } from 'react';
import { generateSummary, generateSummaryAndDetectTone, generateSpeech } from '../services/geminiService';
import { AVAILABLE_VOICES, SUPPORTED_LANGUAGES } from '../constants';
import type { Voice, Language } from '../types';
import { decode, decodeAudioData, audioBufferToMp3Blob } from '../utils/audioUtils';
import { extractTextFromPdf } from '../utils/pdfUtils';
import VoiceSelector from '../components/VoiceSelector';
import LanguageSelector from '../components/LanguageSelector';
import Switch from '../components/Switch';
import { PlayIcon, PauseIcon, LoaderIcon, SparklesIcon, DocumentTextIcon, MicrophoneIcon, SpeakerWaveIcon, DownloadIcon, SpeedIcon, PlusIcon, HistoryIcon, TrashIcon, LanguageIcon, ClipboardDocumentListIcon, ArrowUpTrayIcon, LinkIcon } from '../components/icons';

type InputType = 'text' | 'pdf';
type SummaryHistoryItem = {
  id: string;
  articleSnippet: string;
  summary: string;
  audioB64: string;
};

const HomePage: React.FC = () => {
  const [article, setArticle] = useState<string>('');
  const [personalization, setPersonalization] = useState<string>('');
  const [selectedLanguage, setSelectedLanguage] = useState<string>(SUPPORTED_LANGUAGES[0].id);
  const [selectedVoice, setSelectedVoice] = useState<string>(AVAILABLE_VOICES[0].id);
  const [summary, setSummary] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [detectedTone, setDetectedTone] = useState<string | null>(null);

  const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  
  const [articleQueue, setArticleQueue] = useState<string[]>([]);
  const [isAutoplayEnabled, setIsAutoplayEnabled] = useState<boolean>(true);
  const [isProcessingQueue, setIsProcessingQueue] = useState<boolean>(false);
  const [isToneDetectionEnabled, setIsToneDetectionEnabled] = useState<boolean>(true);
  
  const [summaryHistory, setSummaryHistory] = useState<SummaryHistoryItem[]>([]);
  
  const [inputType, setInputType] = useState<InputType>('text');
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [isParsingPdf, setIsParsingPdf] = useState<boolean>(false);

  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const isAutoplayEnabledRef = useRef(isAutoplayEnabled);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load history from localStorage on initial render
  useEffect(() => {
    try {
      const savedHistory = localStorage.getItem('summaryHistory');
      if (savedHistory) {
        setSummaryHistory(JSON.parse(savedHistory));
      }
    } catch (e) {
      console.error('Failed to load summary history from localStorage', e);
    }
  }, []);

  // Save history to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem('summaryHistory', JSON.stringify(summaryHistory));
    } catch (e) {
      console.error('Failed to save summary history to localStorage', e);
    }
  }, [summaryHistory]);

  useEffect(() => {
    isAutoplayEnabledRef.current = isAutoplayEnabled;
  }, [isAutoplayEnabled]);

  const getAudioContext = useCallback(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    if (audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume();
    }
    return audioContextRef.current;
  }, []);

  useEffect(() => {
    if (isProcessingQueue || articleQueue.length === 0) {
      return;
    }

    const processNextArticle = async () => {
      setIsProcessingQueue(true);
      setIsLoading(true);
      setError(null);
      setSummary('');
      setAudioBuffer(null);
      setDetectedTone(null);

      const nextArticle = articleQueue[0];

      try {
        let summaryText: string;
        let voiceToUse: string = selectedVoice;
        
        if (isToneDetectionEnabled) {
          const result = await generateSummaryAndDetectTone(nextArticle, personalization, selectedLanguage);
          summaryText = result.summary;
          voiceToUse = result.voiceId;
          setDetectedTone(result.detectedTone);
        } else {
          summaryText = await generateSummary(nextArticle, personalization, selectedLanguage);
        }
        
        setSummary(summaryText);

        const audioB64 = await generateSpeech(summaryText, voiceToUse);
        if (audioB64) {
          const newHistoryItem: SummaryHistoryItem = {
            id: new Date().toISOString(),
            articleSnippet: nextArticle.substring(0, 100) + '...',
            summary: summaryText,
            audioB64: audioB64,
          };
          setSummaryHistory(prev => [newHistoryItem, ...prev.slice(0, 19)]); // Keep latest 20

          const audioCtx = getAudioContext();
          const decodedBytes = decode(audioB64);
          const buffer = await decodeAudioData(decodedBytes, audioCtx, 24000, 1);
          setAudioBuffer(buffer);
          playAudio(buffer); 
        } else {
          handlePlaybackEnd();
        }
      } catch (e) {
        console.error(e);
        setError('An error occurred. Skipping to the next item in the queue.');
        handlePlaybackEnd();
      } finally {
        setIsLoading(false);
      }
    };

    processNextArticle();

  }, [articleQueue, isProcessingQueue, personalization, selectedLanguage, selectedVoice, isToneDetectionEnabled, getAudioContext]);

  const handlePlaybackEnd = () => {
    if (isAutoplayEnabledRef.current) {
      setArticleQueue(q => q.slice(1));
      setIsProcessingQueue(false); // Allow useEffect to pick up the next item
    } else {
      setArticleQueue(q => q.slice(1));
      setIsProcessingQueue(false); // Stop processing
    }
  };
  
  const playAudio = (buffer: AudioBuffer) => {
    const audioCtx = getAudioContext();
    if (audioSourceRef.current) {
        audioSourceRef.current.stop();
    }
    const source = audioCtx.createBufferSource();
    source.buffer = buffer;
    source.playbackRate.value = playbackRate;
    source.connect(audioCtx.destination);
    source.onended = () => {
      setIsPlaying(false);
      audioSourceRef.current = null;
      handlePlaybackEnd();
    };
    source.start();
    audioSourceRef.current = source;
    setIsPlaying(true);
  }

  const handlePlayPause = useCallback(() => {
    if (isPlaying) {
      audioSourceRef.current?.stop();
      setIsPlaying(false);
    } else if (audioBuffer) {
      playAudio(audioBuffer);
    }
  }, [audioBuffer, isPlaying, getAudioContext, playbackRate]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPdfFile(file);
      setIsParsingPdf(true);
      setError(null);
      setArticle('');
      try {
        const text = await extractTextFromPdf(file);
        setArticle(text);
      } catch (err) {
        setError('Failed to parse PDF. Please ensure it is a valid, text-based PDF.');
        setPdfFile(null);
      } finally {
        setIsParsingPdf(false);
      }
    }
  };

  const getArticleContent = (): string => {
    if (inputType === 'text') return article.trim();
    if (inputType === 'pdf' && pdfFile) return article.trim();
    return '';
  };
  
  const handleAddToQueue = () => {
    const content = getArticleContent();
    if (!content) return;
    setArticleQueue(prevQueue => [...prevQueue, content]);
    setArticle('');
    setPdfFile(null);
  };
  
  const handleGenerate = () => {
    const content = getArticleContent();
    if (!content && articleQueue.length === 0) {
      setError('Please add an article to the queue or provide content above.');
      return;
    }
    if (content) {
      setArticleQueue(prevQueue => [content, ...prevQueue]);
      setArticle('');
      setPdfFile(null);
    }
  };

  const handleDownload = useCallback(() => {
    if (!audioBuffer) return;

    const mp3Blob = audioBufferToMp3Blob(audioBuffer);
    const url = URL.createObjectURL(mp3Blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'news-summary.mp3';
    document.body.appendChild(a);
a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [audioBuffer]);

  const handlePlaybackRateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newRate = parseFloat(e.target.value);
    setPlaybackRate(newRate);
    if (audioSourceRef.current) {
      audioSourceRef.current.playbackRate.value = newRate;
    }
  };

  const handleSelectHistoryItem = useCallback(async (item: SummaryHistoryItem) => {
    if (isPlaying) {
      audioSourceRef.current?.stop();
    }
    
    setSummary(item.summary);
    setAudioBuffer(null);
    setIsPlaying(false);
    setDetectedTone(null); // History items don't have a tone saved

    try {
      const audioCtx = getAudioContext();
      const decodedBytes = decode(item.audioB64);
      const buffer = await decodeAudioData(decodedBytes, audioCtx, 24000, 1);
      setAudioBuffer(buffer);
    } catch(e) {
      console.error('Failed to load history item audio', e);
      setError('Could not load the audio for this summary.');
    }
  }, [getAudioContext, isPlaying]);

  const handleClearHistory = () => {
    if (window.confirm('Are you sure you want to clear your entire summary history? This cannot be undone.')) {
      setSummaryHistory([]);
    }
  };

  const handleShareSummary = () => {
    if (!summary) return;
    // In a real application, this would generate a unique URL to a page
    // displaying the summary. For this demo, we'll use an alert.
    alert(`Shareable Summary:\n\n${summary}`);
  };

  const isIdle = !isProcessingQueue && !isPlaying;
  const contentForQueue = getArticleContent();
  const canAddToQueue = contentForQueue.length > 0 && !isParsingPdf;
  const canGenerate = (contentForQueue.length > 0 || articleQueue.length > 0) && !isProcessingQueue && !isParsingPdf;

  const TabButton: React.FC<{ type: InputType; label: string; icon: React.ReactNode }> = ({ type, label, icon }) => (
    <button
      onClick={() => { setInputType(type); setError(null); }}
      className={`flex items-center justify-center w-full px-4 py-3 font-semibold text-sm rounded-t-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-custom-primary focus:ring-offset-2 dark:focus:ring-offset-zinc-900 ${
        inputType === type
          ? 'bg-white dark:bg-zinc-800 text-custom-primary border-b-2 border-custom-primary'
          : 'bg-transparent text-custom-subtitle hover:bg-gray-100 dark:hover:bg-zinc-800'
      }`}
    >
      {icon}
      {label}
    </button>
  );

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <main>
          <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-lg shadow-custom-primary/10 p-6 sm:p-8 space-y-8">
            <div className="space-y-6">
              <div>
                <label className="flex items-center text-lg font-semibold mb-2 text-custom-text dark:text-gray-200">
                  <DocumentTextIcon className="w-6 h-6 mr-2 text-custom-primary" />
                  1. Provide Your Content
                </label>
                <div className="border-b border-gray-200 dark:border-gray-700">
                  <nav className="-mb-px flex space-x-2" aria-label="Tabs">
                    <TabButton type="text" label="Paste Text" icon={<ClipboardDocumentListIcon className="w-5 h-5 mr-2" />} />
                    <TabButton type="pdf" label="Upload PDF" icon={<ArrowUpTrayIcon className="w-5 h-5 mr-2" />} />
                  </nav>
                </div>

                <div className="mt-4">
                  {inputType === 'text' && (
                    <textarea
                      id="article"
                      value={article}
                      onChange={(e) => setArticle(e.target.value)}
                      placeholder="Paste the full text of the news article here..."
                      className="w-full h-48 p-4 bg-custom-bg dark:bg-zinc-800 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-custom-primary focus:border-custom-primary transition-colors duration-200 resize-y text-custom-text dark:text-gray-200"
                    />
                  )}
                  {inputType === 'pdf' && (
                     <div className="flex flex-col items-center justify-center w-full h-48 p-4 bg-custom-bg dark:bg-zinc-800 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg">
                        <input
                          type="file"
                          id="pdf-upload"
                          accept=".pdf"
                          onChange={handleFileChange}
                          className="hidden"
                          ref={fileInputRef}
                        />
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          disabled={isParsingPdf}
                          className="inline-flex items-center px-4 py-2 bg-custom-primary text-white font-semibold rounded-lg hover:bg-custom-primary-hover disabled:bg-gray-400"
                        >
                          <ArrowUpTrayIcon className="w-5 h-5 mr-2" />
                          {isParsingPdf ? 'Parsing...' : 'Select PDF File'}
                        </button>
                        {pdfFile && !isParsingPdf && (
                          <p className="mt-4 text-sm text-custom-subtitle dark:text-gray-400">
                            Selected: <span className="font-medium">{pdfFile.name}</span>
                          </p>
                        )}
                        {isParsingPdf && <p className="mt-4 text-sm text-custom-subtitle dark:text-gray-400 animate-pulse">Extracting text, please wait...</p>}
                     </div>
                  )}
                </div>
              </div>

              <div>
                <label htmlFor="personalization" className="flex items-center text-lg font-semibold mb-2 text-custom-text dark:text-gray-200">
                  <SparklesIcon className="w-6 h-6 mr-2 text-custom-primary" />
                  2. Personalization
                </label>
                <textarea
                  id="personalization"
                  value={personalization}
                  onChange={(e) => setPersonalization(e.target.value)}
                  placeholder="e.g., 'Summarize this for a beginner in the field...'"
                  className="w-full h-24 p-4 bg-custom-bg dark:bg-zinc-800 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-custom-primary focus:border-custom-primary transition-colors duration-200 resize-y text-custom-text dark:text-gray-200"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="language" className="flex items-center text-lg font-semibold mb-2 text-custom-text dark:text-gray-200">
                    <LanguageIcon className="w-6 h-6 mr-2 text-custom-primary" />
                    3. Language
                  </label>
                  <LanguageSelector
                    languages={SUPPORTED_LANGUAGES}
                    selectedLanguage={selectedLanguage}
                    onSelectLanguage={setSelectedLanguage}
                  />
                </div>
                <div>
                    <div className="flex items-center justify-between mb-2">
                        <label className="flex items-center text-lg font-semibold text-custom-text dark:text-gray-200">
                            <MicrophoneIcon className="w-6 h-6 mr-2 text-custom-primary" />
                            4. Voice
                        </label>
                        <div className="flex items-center space-x-2">
                            <span className="text-sm font-medium text-custom-subtitle dark:text-gray-400">Mood Voice</span>
                            <Switch id="tone-detect" checked={isToneDetectionEnabled} onChange={setIsToneDetectionEnabled} />
                        </div>
                    </div>
                    <VoiceSelector
                        voices={AVAILABLE_VOICES}
                        selectedVoice={selectedVoice}
                        onSelectVoice={setSelectedVoice}
                        disabled={isToneDetectionEnabled}
                    />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={handleGenerate}
                  disabled={!canGenerate}
                  className="w-full flex-grow inline-flex items-center justify-center px-8 py-3 bg-custom-secondary text-custom-text font-bold rounded-lg hover:opacity-90 disabled:bg-gray-300 dark:disabled:bg-zinc-700 disabled:text-gray-500 dark:disabled:text-gray-400 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 disabled:scale-100 shadow-lg shadow-custom-secondary/30"
                >
                  {isLoading && isProcessingQueue ? (
                    <>
                      <LoaderIcon className="w-6 h-6 mr-3 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <SparklesIcon className="w-6 h-6 mr-3" />
                      Generate Summary
                    </>
                  )}
                </button>
                <button
                  onClick={handleAddToQueue}
                  disabled={!canAddToQueue}
                  className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 bg-gray-200 dark:bg-zinc-700 text-custom-text dark:text-white font-bold rounded-lg hover:bg-gray-300 dark:hover:bg-zinc-600 disabled:bg-gray-200 dark:disabled:bg-zinc-700 disabled:text-gray-400 dark:disabled:text-gray-400 disabled:cursor-not-allowed transition-colors"
                  aria-label="Add to Queue"
                >
                  <PlusIcon className="w-6 h-6 mr-2" />
                  Add to Queue
                </button>
              </div>
              {articleQueue.length > 0 && (
                <p className="text-center text-sm text-custom-subtitle dark:text-gray-400">
                  {isProcessingQueue ? `Processing 1 of ${articleQueue.length}...` : `${articleQueue.length} item(s) in queue.`}
                </p>
              )}
              {error && <p className="text-red-600 dark:text-red-400 mt-4 text-center">{error}</p>}
            </div>
            
            {(summary || isLoading) && (
              <div className={`mt-10 transition-opacity duration-500 ${isLoading && !summary ? 'opacity-50' : 'opacity-100'}`}>
                <div className="border-t border-gray-200 dark:border-gray-700 my-8"></div>
                <h2 className="text-2xl font-bold text-center mb-6 text-custom-text dark:text-white">Your Summary</h2>
                
                {audioBuffer && (
                  <div className="bg-white dark:bg-zinc-900 rounded-lg p-6 mb-6 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-md">
                    <div className="flex items-center flex-shrink-0">
                      <SpeakerWaveIcon className="w-8 h-8 text-custom-primary mr-4" />
                      <div>
                        <div className="flex items-center gap-3">
                            <h3 className="text-lg font-semibold">Audio Playback</h3>
                            {detectedTone && (
                                <span className="bg-custom-primary/10 text-custom-primary text-xs font-semibold px-2.5 py-1 rounded-full">{detectedTone} Tone</span>
                            )}
                        </div>
                        <p className="text-sm text-custom-subtitle dark:text-gray-400">Ready to listen</p>
                      </div>
                    </div>
                    <div className="w-full flex flex-col sm:flex-row items-center justify-end gap-6 flex-wrap">
                      <div className="flex items-center gap-2">
                          <label htmlFor="autoplay" className="text-sm text-custom-subtitle dark:text-gray-400">Autoplay Next</label>
                          <Switch id="autoplay" checked={isAutoplayEnabled} onChange={setIsAutoplayEnabled} />
                      </div>
                      <div className="flex items-center gap-2">
                        <SpeedIcon className="w-6 h-6 text-custom-subtitle dark:text-gray-400" />
                        <input
                            type="range"
                            min="0.5"
                            max="2"
                            step="0.25"
                            value={playbackRate}
                            onChange={handlePlaybackRateChange}
                            className="w-24 h-2 bg-gray-300 dark:bg-zinc-700 rounded-lg appearance-none cursor-pointer"
                            aria-label="Playback speed"
                        />
                        <span className="text-sm font-mono text-custom-subtitle dark:text-gray-400 w-10 text-center">{playbackRate.toFixed(2)}x</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <button
                          onClick={handleDownload}
                          className="p-3 bg-gray-200 dark:bg-zinc-700 rounded-full text-custom-text dark:text-white hover:bg-gray-300 dark:hover:bg-zinc-600 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-zinc-900 focus:ring-custom-primary"
                          aria-label="Download audio summary"
                        >
                          <DownloadIcon className="w-6 h-6" />
                        </button>
                        <button 
                          onClick={handlePlayPause} 
                          disabled={isProcessingQueue}
                          className="p-3 bg-custom-primary rounded-full text-white hover:bg-custom-primary-hover transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-zinc-900 focus:ring-custom-primary disabled:bg-gray-400 dark:disabled:bg-zinc-700"
                          aria-label={isPlaying ? "Pause" : "Play"}
                        >
                          {isPlaying ? <PauseIcon className="w-8 h-8"/> : <PlayIcon className="w-8 h-8" />}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
                
                <div className="bg-custom-bg/70 dark:bg-dark-bg/70 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-4">Text Version</h3>
                  {summary ? (
                    <>
                      <p className="text-custom-text dark:text-gray-300 leading-relaxed whitespace-pre-wrap">{summary}</p>
                      <div className="mt-4 pt-4 border-t border-gray-300 dark:border-zinc-700 flex justify-end">
                        <button
                          onClick={handleShareSummary}
                          className="inline-flex items-center px-4 py-2 bg-transparent text-custom-primary font-semibold rounded-lg hover:bg-custom-primary/10 transition-colors"
                        >
                          <LinkIcon className="w-5 h-5 mr-2" />
                          Share Summary
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="space-y-3 animate-pulse">
                      <div className="h-4 bg-gray-300 dark:bg-zinc-700 rounded w-3/4"></div>
                      <div className="h-4 bg-gray-300 dark:bg-zinc-700 rounded w-full"></div>
                      <div className="h-4 bg-gray-300 dark:bg-zinc-700 rounded w-5/6"></div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {summaryHistory.length > 0 && (
            <section className="mt-12">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold flex items-center text-custom-text dark:text-white">
                  <HistoryIcon className="w-7 h-7 mr-3 text-custom-primary" />
                  Summary History
                </h2>
                <button
                  onClick={handleClearHistory}
                  className="flex items-center text-sm font-semibold text-custom-subtitle hover:text-red-600 dark:text-gray-400 dark:hover:text-red-500 transition-colors"
                  aria-label="Clear all history"
                >
                  <TrashIcon className="w-5 h-5 mr-2" />
                  Clear History
                </button>
              </div>
              <div className="space-y-3">
                {summaryHistory.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleSelectHistoryItem(item)}
                    className="w-full text-left p-4 rounded-lg bg-white hover:bg-gray-50 dark:bg-zinc-800 dark:hover:bg-zinc-700 transition-colors focus:outline-none focus:ring-2 focus:ring-custom-primary"
                  >
                    <p className="font-semibold text-custom-text dark:text-gray-200 truncate">{item.articleSnippet}</p>
                    <p className="text-sm text-custom-subtitle dark:text-gray-400 mt-1 truncate">{item.summary}</p>
                  </button>
                ))}
              </div>
            </section>
          )}
        </main>
      </div>
    </div>
  );
};

export default HomePage;

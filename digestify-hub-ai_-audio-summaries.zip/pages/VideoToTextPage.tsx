import React, { useState, useRef } from 'react';
import { summarizeVideo } from '../services/geminiService';
import { ArrowUpTrayIcon, LoaderIcon, VideoCameraIcon, DocumentTextIcon, ClipboardDocumentListIcon, DownloadIcon } from '../components/icons';

const VideoToTextPage: React.FC = () => {
    const [videoFile, setVideoFile] = useState<File | null>(null);
    const [summary, setSummary] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setVideoFile(file);
            setSummary('');
            setError(null);
        }
    };

    const handleSummarize = async () => {
        if (!videoFile) {
            setError('Please select a video file first.');
            return;
        }

        setIsLoading(true);
        setError(null);
        setSummary('');
        try {
            const result = await summarizeVideo(videoFile);
            setSummary(result);
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
            setError(errorMessage);
        } finally {
            setIsLoading(false);
        }
    };

    const handleCopyToClipboard = () => {
        if (summary) {
            navigator.clipboard.writeText(summary);
            // Optionally, show a confirmation message
        }
    };

    const handleDownload = () => {
        if (!summary) return;

        const blob = new Blob([summary], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'video-summary.txt';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const canSummarize = !isLoading && videoFile;

    return (
        <div className="p-4 sm:p-6 lg:p-8">
            <div className="max-w-4xl mx-auto">
                <main className="space-y-8 mt-8">
                    <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-lg shadow-custom-primary/10 p-6 sm:p-8 space-y-6">
                        <div>
                            <label className="flex items-center text-lg font-semibold mb-2 text-custom-text dark:text-gray-200">
                                <VideoCameraIcon className="w-6 h-6 mr-2 text-custom-primary" />
                                1. Upload Your Video
                            </label>
                            <div className="mt-4">
                                <div className="flex flex-col items-center justify-center w-full h-48 p-4 bg-custom-bg dark:bg-zinc-800 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg">
                                    <input
                                        type="file"
                                        id="video-upload"
                                        accept="video/*"
                                        onChange={handleFileChange}
                                        className="hidden"
                                        ref={fileInputRef}
                                    />
                                    <button
                                        onClick={() => fileInputRef.current?.click()}
                                        disabled={isLoading}
                                        className="inline-flex items-center px-4 py-2 bg-custom-primary text-white font-semibold rounded-lg hover:bg-custom-primary-hover disabled:bg-gray-400"
                                    >
                                        <ArrowUpTrayIcon className="w-5 h-5 mr-2" />
                                        Select Video File
                                    </button>
                                    {videoFile && (
                                        <p className="mt-4 text-sm text-custom-subtitle dark:text-gray-400">
                                            Selected: <span className="font-medium">{videoFile.name}</span>
                                        </p>
                                    )}
                                </div>
                            </div>
                        </div>

                        <button
                            onClick={handleSummarize}
                            disabled={!canSummarize}
                            className="w-full flex-grow inline-flex items-center justify-center px-8 py-3 bg-custom-secondary text-custom-text font-bold rounded-lg hover:opacity-90 disabled:bg-gray-300 dark:disabled:bg-zinc-700 disabled:text-gray-500 dark:disabled:text-gray-400 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 disabled:scale-100 shadow-lg shadow-custom-secondary/30"
                        >
                            {isLoading ? (
                                <>
                                    <LoaderIcon className="w-6 h-6 mr-3 animate-spin" />
                                    Summarizing...
                                </>
                            ) : (
                                <>
                                    <DocumentTextIcon className="w-6 h-6 mr-3" />
                                    Summarize Video
                                </>
                            )}
                        </button>
                        {error && <p className="text-red-600 dark:text-red-400 mt-2 text-center">{error}</p>}
                    </div>

                    {(summary || isLoading) && (
                        <div className={`transition-opacity duration-500 ${isLoading && !summary ? 'opacity-50' : 'opacity-100'}`}>
                             <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-lg shadow-custom-primary/10 p-6 sm:p-8 space-y-4">
                                <div className="flex justify-between items-center">
                                    <h2 className="text-2xl font-bold text-custom-text dark:text-white">Summary Result</h2>
                                    <div className="flex items-center space-x-4">
                                        <button 
                                            onClick={handleCopyToClipboard}
                                            disabled={!summary}
                                            className="flex items-center text-sm font-semibold text-custom-primary hover:underline disabled:opacity-50"
                                            aria-label="Copy to clipboard"
                                        >
                                            <ClipboardDocumentListIcon className="w-5 h-5 mr-2"/>
                                            Copy
                                        </button>
                                        <button
                                            onClick={handleDownload}
                                            disabled={!summary}
                                            className="flex items-center text-sm font-semibold text-custom-primary hover:underline disabled:opacity-50"
                                            aria-label="Download summary"
                                        >
                                            <DownloadIcon className="w-5 h-5 mr-2" />
                                            Download
                                        </button>
                                    </div>
                                </div>
                                <div className="bg-custom-bg/70 dark:bg-dark-bg/70 p-6 rounded-lg min-h-[150px]">
                                    {summary ? (
                                        <p className="text-custom-text dark:text-gray-300 leading-relaxed whitespace-pre-wrap">{summary}</p>
                                    ) : (
                                        <div className="space-y-3 animate-pulse">
                                            <div className="h-4 bg-gray-300 dark:bg-zinc-700 rounded w-3/4"></div>
                                            <div className="h-4 bg-gray-300 dark:bg-zinc-700 rounded w-full"></div>
                                            <div className="h-4 bg-gray-300 dark:bg-zinc-700 rounded w-5/6"></div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                </main>
            </div>
        </div>
    );
};

export default VideoToTextPage;
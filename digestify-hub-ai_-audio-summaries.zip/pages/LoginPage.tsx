

import React, { useState, FormEvent } from 'react';
import { useAuth } from '../auth';
import { SparklesIcon } from '../components/icons';

interface LoginPageProps {
    onSwitchToSignUp: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onSwitchToSignUp }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const { signIn } = useAuth();

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        setError('');
        if (!signIn(username, password)) {
            setError('Invalid username or password.');
        }
    };

    return (
        <div className="min-h-screen bg-custom-bg dark:bg-dark-bg flex items-center justify-center p-4 font-sans">
            <div className="w-full max-w-md">
                <div className="text-center mb-8">
                    <SparklesIcon className="w-12 h-12 text-custom-primary mx-auto mb-3"/>
                    <h1 className="text-3xl font-bold text-custom-text dark:text-white">Welcome Back</h1>
                    <p className="text-custom-subtitle dark:text-gray-400 mt-2">Sign in to continue to Digestify Hub AI.</p>
                </div>
                <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-lg shadow-custom-primary/10 p-8">
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label htmlFor="username" className="block text-sm font-medium text-custom-text dark:text-gray-300">
                                Username
                            </label>
                            <input
                                id="username"
                                type="text"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                                className="mt-1 block w-full px-3 py-2 bg-custom-bg dark:bg-zinc-800 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-custom-primary focus:border-custom-primary"
                            />
                        </div>
                        <div>
                            <label htmlFor="password"  className="block text-sm font-medium text-custom-text dark:text-gray-300">
                                Password
                            </label>
                            <input
                                id="password"
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                                className="mt-1 block w-full px-3 py-2 bg-custom-bg dark:bg-zinc-800 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-custom-primary focus:border-custom-primary"
                            />
                        </div>
                        {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
                        <div>
                            <button
                                type="submit"
                                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-bold text-custom-text bg-custom-secondary hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-zinc-900 focus:ring-custom-primary"
                            >
                                Sign In
                            </button>
                        </div>
                    </form>
                    <p className="mt-6 text-center text-sm text-custom-subtitle dark:text-gray-400">
                        Don't have an account?{' '}
                        <button onClick={onSwitchToSignUp} className="font-medium text-custom-primary hover:text-custom-primary-hover">
                            Sign Up
                        </button>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default LoginPage;
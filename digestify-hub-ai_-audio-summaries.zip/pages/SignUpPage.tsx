

import React, { useState, FormEvent } from 'react';
import { useAuth } from '../auth';
import { SparklesIcon } from '../components/icons';

interface SignUpPageProps {
    onSwitchToLogin: () => void;
}

const SignUpPage: React.FC<SignUpPageProps> = ({ onSwitchToLogin }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const { signUp } = useAuth();

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        setError('');
        if (password !== confirmPassword) {
            setError('Passwords do not match.');
            return;
        }
        if (password.length < 6) {
            setError('Password must be at least 6 characters long.');
            return;
        }
        if (!signUp(username, password)) {
            setError('Username is already taken.');
        }
    };

    return (
        <div className="min-h-screen bg-custom-bg dark:bg-dark-bg flex items-center justify-center p-4 font-sans">
            <div className="w-full max-w-md">
                 <div className="text-center mb-8">
                    <SparklesIcon className="w-12 h-12 text-custom-primary mx-auto mb-3"/>
                    <h1 className="text-3xl font-bold text-custom-text dark:text-white">Create an Account</h1>
                    <p className="text-custom-subtitle dark:text-gray-400 mt-2">Join Digestify Hub AI today.</p>
                </div>
                <div className="bg-white dark:bg-zinc-900 rounded-2xl shadow-lg shadow-custom-primary/10 p-8">
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label htmlFor="username-signup" className="block text-sm font-medium text-custom-text dark:text-gray-300">
                                Username
                            </label>
                            <input
                                id="username-signup"
                                type="text"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                                className="mt-1 block w-full px-3 py-2 bg-custom-bg dark:bg-zinc-800 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-custom-primary focus:border-custom-primary"
                            />
                        </div>
                        <div>
                            <label htmlFor="password-signup" className="block text-sm font-medium text-custom-text dark:text-gray-300">
                                Password
                            </label>
                            <input
                                id="password-signup"
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                                className="mt-1 block w-full px-3 py-2 bg-custom-bg dark:bg-zinc-800 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-custom-primary focus:border-custom-primary"
                            />
                        </div>
                         <div>
                            <label htmlFor="confirm-password-signup" className="block text-sm font-medium text-custom-text dark:text-gray-300">
                                Confirm Password
                            </label>
                            <input
                                id="confirm-password-signup"
                                type="password"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                                required
                                className="mt-1 block w-full px-3 py-2 bg-custom-bg dark:bg-zinc-800 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-custom-primary focus:border-custom-primary"
                            />
                        </div>
                        {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
                        <div>
                            <button
                                type="submit"
                                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-bold text-custom-text bg-custom-secondary hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-zinc-900 focus:ring-custom-primary"
                            >
                                Sign Up
                            </button>
                        </div>
                    </form>
                    <p className="mt-6 text-center text-sm text-custom-subtitle dark:text-gray-400">
                        Already have an account?{' '}
                        <button onClick={onSwitchToLogin} className="font-medium text-custom-primary hover:text-custom-primary-hover">
                            Sign In
                        </button>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default SignUpPage;

import type { Voice, Language } from './types';

export const AVAILABLE_VOICES: Voice[] = [
  { id: 'Kore', name: 'Kore (Female)' },
  { id: 'Puck', name: 'Puck (Male)' },
  { id: 'Charon', name: 'Charon (Male)' },
  { id: 'Zephyr', name: 'Zephyr (Female)' },
  { id: 'Fenrir', name: 'Fenrir (Male)' },
];

export const SUPPORTED_LANGUAGES: Language[] = [
  { id: 'English', name: 'English' },
  { id: 'Spanish', name: 'Español' },
  { id: 'French', name: 'Français' },
  { id: 'German', name: 'Deutsch' },
  { id: 'Hindi', name: 'हिन्दी' },
  { id: 'Japanese', name: '日本語' },
];


import React from 'react';
import type { Page } from '../App';
import { HomeIcon, InformationCircleIcon, WaveformIcon, SparklesIcon, XMarkIcon, VideoCameraIcon, ArrowRightOnRectangleIcon } from './icons';
import { useAuth } from '../auth';

interface SidebarProps {
  isSidebarOpen: boolean;
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  closeSidebar: () => void;
}

const NavItem: React.FC<{
  page: Page;
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  icon: React.ReactNode;
  label: string;
}> = ({ page, currentPage, setCurrentPage, icon, label }) => {
  const isActive = currentPage === page;
  return (
    <li>
      <button
        onClick={() => setCurrentPage(page)}
        className={`flex items-center p-3 my-1 w-full text-left rounded-lg transition-colors duration-200 ${
          isActive
            ? 'bg-custom-primary/20 text-custom-primary font-semibold'
            : 'text-custom-subtitle dark:text-gray-400 hover:bg-gray-200/50 dark:hover:bg-zinc-800/50'
        }`}
      >
        <span className={`w-6 h-6 mr-4 ${isActive ? 'text-custom-primary' : ''}`}>{icon}</span>
        {label}
      </button>
    </li>
  );
};

const Sidebar: React.FC<SidebarProps> = ({ isSidebarOpen, currentPage, setCurrentPage, closeSidebar }) => {
  const { user, signOut } = useAuth();

  return (
    <aside className={`fixed top-0 left-0 z-40 w-64 h-screen bg-white/80 dark:bg-zinc-900/80 backdrop-blur-lg border-r border-gray-200 dark:border-zinc-800 flex flex-col p-4 transition-transform duration-300 ease-in-out md:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex items-center justify-between mb-10 px-2">
         <div className="flex items-center">
            <SparklesIcon className="w-8 h-8 text-custom-primary mr-3"/>
            <h1 className="text-xl font-bold text-custom-text dark:text-white">Digestify Hub AI</h1>
         </div>
         <button onClick={closeSidebar} className="md:hidden p-1 text-custom-subtitle dark:text-gray-400 hover:text-custom-text dark:hover:text-white">
            <XMarkIcon className="w-6 h-6" />
         </button>
      </div>
      <nav className="flex-grow">
        <ul>
          <NavItem
            page="home"
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            icon={<HomeIcon />}
            label="Home"
          />
          <NavItem
            page="audio-to-text"
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            icon={<WaveformIcon />}
            label="Audio to Text"
          />
          <NavItem
            page="video-to-text"
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            icon={<VideoCameraIcon />}
            label="Video to Text"
          />
          <NavItem
            page="about"
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            icon={<InformationCircleIcon />}
            label="About Us"
          />
        </ul>
      </nav>

      <div className="border-t border-gray-200 dark:border-zinc-800 pt-4">
        {user && (
            <div className="px-2 mb-2">
                <p className="text-sm text-custom-subtitle dark:text-gray-400">Signed in as</p>
                <p className="font-semibold text-custom-text dark:text-white truncate">{user.username}</p>
            </div>
        )}
        <button
            onClick={signOut}
            className="flex items-center p-3 my-1 w-full text-left rounded-lg text-custom-subtitle dark:text-gray-400 hover:bg-gray-200/50 dark:hover:bg-zinc-800/50"
        >
            <ArrowRightOnRectangleIcon className="w-6 h-6 mr-4" />
            Sign Out
        </button>
      </div>

    </aside>
  );
};

export default Sidebar;
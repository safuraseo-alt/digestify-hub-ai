

import React from 'react';
import type { Page, Theme } from '../App';
import ThemeToggle from './ThemeToggle';
import { Bars3Icon } from './icons';

interface HeaderProps {
    toggleSidebar: () => void;
    page: Page;
    theme: Theme;
    toggleTheme: () => void;
}

const pageTitles: Record<Page, string> = {
    home: 'Digestify Hub AI',
    'audio-to-text': 'Audio to Text Transcription',
    'video-to-text': 'Video to Text Summary',
    about: 'About Us'
};

const pageSubtitles: Record<Page, string> = {
    home: 'Your Personalized Audio Digest',
    'audio-to-text': 'Your Personal Transcription Assistant',
    'video-to-text': 'Get Key Insights From Your Videos',
    about: 'Transforming Your Information Diet'
};

const Header: React.FC<HeaderProps> = ({ toggleSidebar, page, theme, toggleTheme }) => {
    return (
        <header className="sticky top-0 bg-custom-bg/80 dark:bg-dark-bg/80 backdrop-blur-lg z-30 p-4 sm:p-6 lg:p-8">
             <div className="max-w-4xl mx-auto flex justify-between items-center">
                <div className="flex items-center">
                    <button 
                        onClick={toggleSidebar} 
                        className="p-2 mr-4 rounded-full text-custom-subtitle dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-zinc-800 md:hidden"
                        aria-label="Open sidebar"
                    >
                        <Bars3Icon className="w-6 h-6" />
                    </button>
                    <div>
                        <h1 className="text-2xl md:text-3xl font-bold text-custom-text dark:text-white">{pageTitles[page]}</h1>
                        <p className="text-md text-custom-primary hidden sm:block">{pageSubtitles[page]}</p>
                    </div>
                </div>
                <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
             </div>
        </header>
    )
};

export default Header;
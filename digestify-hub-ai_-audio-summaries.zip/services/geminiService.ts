import { GoogleGenAI, Modality, Type } from "@google/genai";
import { fileToBase64 } from "../utils/fileUtils";

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export async function generateSummary(article: string, personalization: string, language: string): Promise<string> {
  const model = 'gemini-2.5-flash';
  
  const prompt = `
    Summarize the following text in ${language}.
    
    ${personalization ? `Personalization instructions: ${personalization}` : ''}
    
    Here is the text:
    ---
    ${article}
    ---
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating summary:", error);
    throw new Error("Failed to generate summary.");
  }
}

const toneToVoiceMap: Record<string, string> = {
  'Informative': 'Kore',
  'Formal': 'Charon',
  'Serious': 'Fenrir',
  'Happy': 'Zephyr',
  'Humorous': 'Puck',
  'Sad': 'Puck',
  'Neutral': 'Kore',
};

const possibleTones = Object.keys(toneToVoiceMap);

export interface SummaryWithToneResult {
  summary: string;
  detectedTone: string;
  voiceId: string;
}

export async function generateSummaryAndDetectTone(article: string, personalization: string, language: string): Promise<SummaryWithToneResult> {
    const model = 'gemini-2.5-flash';
    
    const prompt = `
        Analyze the tone of the following text and provide a one-word descriptor from this list: ${possibleTones.join(', ')}.
        Then, summarize the text in ${language}.
        ${personalization ? `Personalization instructions for the summary: ${personalization}` : ''}
        
        Here is the text:
        ---
        ${article}
        ---
    `;

    try {
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        summary: {
                            type: Type.STRING,
                            description: "The generated summary of the article."
                        },
                        tone: {
                            type: Type.STRING,
                            description: `The detected tone of the article. Must be one of: ${possibleTones.join(', ')}.`
                        }
                    },
                    required: ["summary", "tone"]
                }
            }
        });

        const resultJson = JSON.parse(response.text);
        const summary = resultJson.summary;
        const detectedTone = resultJson.tone;

        const voiceId = toneToVoiceMap[detectedTone] || 'Kore'; // Default to 'Kore' if tone is unexpected

        return { summary, detectedTone, voiceId };

    } catch (error) {
        console.error("Error generating summary with tone detection:", error);
        throw new Error("Failed to generate summary with tone detection.");
    }
}


export async function generateSpeech(text: string, voiceName: string): Promise<string> {
  const model = 'gemini-2.5-flash-preview-tts';
  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: [{ parts: [{ text: text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voiceName },
          },
        },
      },
    });

    const audioData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    
    if (!audioData) {
      throw new Error("No audio data received from API.");
    }
    
    return audioData;
  } catch (error) {
    console.error("Error generating speech:", error);
    throw new Error("Failed to generate speech.");
  }
}


export async function transcribeAudio(audioFile: File): Promise<string> {
    const model = 'gemini-2.5-flash';

    const audioPart = {
      inlineData: {
        data: await fileToBase64(audioFile),
        mimeType: audioFile.type,
      },
    };

    const prompt = "Transcribe the following audio recording accurately. Provide only the transcribed text, without any additional commentary or formatting.";

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: { parts: [audioPart, { text: prompt }] },
        });
        return response.text;
    } catch (error) {
        console.error("Error transcribing audio:", error);
        throw new Error("Failed to transcribe audio. Please ensure the audio format is supported.");
    }
}

export async function summarizeVideo(videoFile: File): Promise<string> {
    const model = 'gemini-2.5-flash';

    const videoPart = {
      inlineData: {
        data: await fileToBase64(videoFile),
        mimeType: videoFile.type,
      },
    };

    const prompt = "Analyze the content of this video and provide a concise, well-structured summary. Highlight the key points, main topics discussed, and any important conclusions. The summary should be easy to read and capture the essence of the video.";

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: { parts: [videoPart, { text: prompt }] },
        });
        return response.text;
    } catch (error) {
        console.error("Error summarizing video:", error);
        throw new Error("Failed to summarize video. Please ensure the video format is supported and not too large.");
    }
}
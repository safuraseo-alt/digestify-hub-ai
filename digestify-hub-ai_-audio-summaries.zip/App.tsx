
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import AboutUsPage from './pages/AboutUsPage';
import AudioToTextPage from './pages/AudioToTextPage';
import VideoToTextPage from './pages/VideoToTextPage';
import LoginPage from './pages/LoginPage';
import SignUpPage from './pages/SignUpPage';
import { useAuth } from './auth';

export type Page = 'home' | 'about' | 'audio-to-text' | 'video-to-text';
export type Theme = 'light' | 'dark';

const App: React.FC = () => {
    const { user } = useAuth();
    const [authPage, setAuthPage] = useState<'login' | 'signup'>('login');
    const [currentPage, setCurrentPage] = useState<Page>('home');
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const [theme, setTheme] = useState<Theme>(() => {
        const savedTheme = localStorage.getItem('theme') as Theme | null;
        if (savedTheme) {
            return savedTheme;
        }
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    });

    useEffect(() => {
        if (theme === 'dark') {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
        localStorage.setItem('theme', theme);
    }, [theme]);

    const toggleTheme = () => {
        setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
    };

    const renderPage = () => {
        switch (currentPage) {
            case 'home':
                return <HomePage />;
            case 'about':
                return <AboutUsPage />;
            case 'audio-to-text':
                return <AudioToTextPage />;
            case 'video-to-text':
                return <VideoToTextPage />;
            default:
                return <HomePage />;
        }
    };
    
    useEffect(() => {
        // Apply theme to the body for auth pages
        if (!user) {
             if (theme === 'dark') {
                document.body.classList.add('dark');
             } else {
                document.body.classList.remove('dark');
             }
        }
    }, [user, theme]);


    if (!user) {
        return authPage === 'login' 
          ? <LoginPage onSwitchToSignUp={() => setAuthPage('signup')} />
          : <SignUpPage onSwitchToLogin={() => setAuthPage('login')} />;
    }

    return (
        <div className="min-h-screen bg-custom-bg dark:bg-dark-bg text-custom-text dark:text-white font-sans transition-colors duration-300">
            <Sidebar 
                isSidebarOpen={isSidebarOpen} 
                currentPage={currentPage} 
                setCurrentPage={setCurrentPage}
                closeSidebar={() => setIsSidebarOpen(false)}
            />
            <div className={`transition-all duration-300 ease-in-out ${isSidebarOpen ? 'md:pl-64' : 'pl-0'}`}>
                <Header 
                    toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} 
                    page={currentPage}
                    theme={theme}
                    toggleTheme={toggleTheme}
                />
                <div className="flex-1 overflow-auto">
                    {renderPage()}
                </div>
            </div>
        </div>
    );
};

export default App;